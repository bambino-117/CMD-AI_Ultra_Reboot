# 🚀 Guide d'Installation - CMD-AI_Ultra_Reboot v2.1.0

## 📋 Prérequis
- Python 3.8+
- Windows 10/11, macOS, ou Linux
- Connexion Internet (pour les modèles IA)

## 🔧 Installation Rapide

### Windows
1. Téléchargez l'archive
2. Extrayez dans un dossier
3. **Exécutez `security/auto_install.bat` en tant qu'administrateur**
4. Lancez `python main.py`

### Linux/macOS
```bash
# Extraire l'archive
unzip CMD-AI_Ultra_Reboot_v2.1.0.zip
cd CMD-AI_Ultra_Reboot_v2.1.0

# Installer les dépendances
pip3 install -r requirements.txt

# Lancer l'application
python3 main.py
```

## 🛡️ Résolution des Problèmes de Sécurité

### Windows Defender
- Utilisez `security/defender_exclusion.ps1`
- Ou ajoutez manuellement le dossier aux exclusions

### Navigateurs
- Chrome: "Conserver" → "Conserver quand même"
- Firefox: "..." → "Conserver le fichier"
- Edge: "Conserver" → "Afficher plus" → "Conserver quand même"

### Antivirus Tiers
- Ajoutez le dossier d'installation aux exclusions
- Consultez `security/security_report.txt`

## 🔗 Nouvelles Fonctionnalités v2.1.0

### Extensions Sécurité
- **BadUSB Creator**: Création de payloads USB
- **OSINT Extension**: Recherche d'informations
- **Security Toolkit**: Outils de sécurité
- **USB Manager**: Gestion avancée USB

### Liaisons Intelligentes
- Intégration automatique entre extensions
- Workflows de sécurité prédéfinis
- Analyse collaborative IA + Sécurité

### Système de Réparation
- Détection automatique des erreurs
- Réparation en temps réel
- Notifications de maintenance

## 📞 Support
- GitHub: https://github.com/bambino-117/CMD-AI_Ultra_Reboot
- Issues: Signalez les problèmes sur GitHub
- Wiki: Documentation complète disponible
