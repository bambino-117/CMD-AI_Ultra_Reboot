# Script d'exclusion Windows Defender pour CMD-AI Ultra Reboot
# À exécuter en tant qu'administrateur

Write-Host "🛡️ Configuration Windows Defender pour CMD-AI Ultra Reboot" -ForegroundColor Green

# Exclusions de dossiers
$folders = @(
    "$env:USERPROFILE\Desktop\CMD-AI_Ultra_Reboot",
    "$env:USERPROFILE\Downloads\CMD-AI_Ultra_Reboot*",
    "$env:APPDATA\CMD-AI_Ultra_Reboot",
    "$env:TEMP\CMD-AI_Ultra_Reboot*"
)

foreach ($folder in $folders) {
    try {
        Add-MpPreference -ExclusionPath $folder -Force
        Write-Host "✅ Dossier exclu: $folder" -ForegroundColor Green
    } catch {
        Write-Host "⚠️ Erreur pour: $folder" -ForegroundColor Yellow
    }
}

# Exclusions de processus
$processes = @(
    "CMD-AI_Ultra_Reboot*.exe",
    "python.exe",
    "pythonw.exe"
)

foreach ($process in $processes) {
    try {
        Add-MpPreference -ExclusionProcess $process -Force
        Write-Host "✅ Processus exclu: $process" -ForegroundColor Green
    } catch {
        Write-Host "⚠️ Erreur pour: $process" -ForegroundColor Yellow
    }
}

Write-Host "🎉 Configuration terminée !" -ForegroundColor Green
Write-Host "Redémarrez votre ordinateur pour appliquer les changements." -ForegroundColor Cyan
