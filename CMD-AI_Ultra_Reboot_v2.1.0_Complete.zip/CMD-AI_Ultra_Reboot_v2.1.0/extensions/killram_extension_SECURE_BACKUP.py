from core.base_extension import BaseExtension
import os
import platform
import subprocess
import threading
import time
import gc

class KillRAMExtension(BaseExtension):
    def __init__(self):
        super().__init__()
        self.name = "KillRAM"
        self.version = "1.0.0"
        self.description = "⚠️ OUTIL DESTRUCTIF - Saturation mémoire système"
        self.author = "CMD-AI Team"
        self.os_type = platform.system()
        self.disclaimer_accepted = False
        self.kill_threads = []
        self.is_running = False
    
    def initialize(self, app_context):
        self.app_context = app_context
    
    def execute(self, command, args=None):
        if command == "disclaimer":
            return self.show_disclaimer()
        elif command == "accept":
            return self.accept_disclaimer()
        elif command == "start":
            return self.start_kill_process(args)
        elif command == "stop":
            return self.stop_kill_process()
        elif command == "status":
            return self.get_status()
        elif command == "help":
            return self.show_help()
        else:
            return self.show_disclaimer()
    
    def show_disclaimer(self):
        """Affiche la décharge de responsabilité"""
        return """⚠️ DÉCHARGE DE RESPONSABILITÉ - KILLRAM

╔══════════════════════════════════════════════════════════════╗
║                    ⚠️ AVERTISSEMENT CRITIQUE ⚠️                ║
╚══════════════════════════════════════════════════════════════╝

🚨 CETTE EXTENSION EST POTENTIELLEMENT DESTRUCTIVE 🚨

📋 QUE FAIT KILLRAM :
• Sature la mémoire RAM du système
• Peut provoquer un crash système complet
• Peut causer une perte de données non sauvegardées
• Peut endommager le système d'exploitation
• Peut nécessiter un redémarrage forcé

⚖️ DÉCHARGE DE RESPONSABILITÉ LÉGALE :

EN UTILISANT CETTE EXTENSION, VOUS RECONNAISSEZ ET ACCEPTEZ QUE :

1. 🛡️ LE DÉVELOPPEUR (CMD-AI Team) DÉCLINE TOUTE RESPONSABILITÉ
   pour les dommages directs, indirects, accessoires ou consécutifs
   résultant de l'utilisation de cette extension.

2. 💾 VOUS ÊTES SEUL RESPONSABLE de sauvegarder vos données
   avant d'utiliser cet outil.

3. 🖥️ VOUS UTILISEZ CET OUTIL À VOS PROPRES RISQUES
   et assumez l'entière responsabilité des conséquences.

4. 🔧 CET OUTIL EST DESTINÉ À DES FINS ÉDUCATIVES ET DE TEST
   dans des environnements contrôlés uniquement.

5. 🚫 LE DÉVELOPPEUR NE PEUT ÊTRE TENU RESPONSABLE
   de la perte de données, corruption système, ou tout autre dommage.

⚠️ UTILISATIONS LÉGITIMES :
• Tests de stress mémoire
• Simulation de conditions de faible mémoire
• Tests de robustesse d'applications
• Recherche en sécurité informatique

🚨 UTILISATIONS INTERDITES :
• Attaques malveillantes
• Sabotage de systèmes tiers
• Déni de service
• Toute utilisation illégale

═══════════════════════════════════════════════════════════════

Pour accepter ces conditions et activer l'extension :
ext KillRAM accept

Pour annuler et quitter :
Fermez simplement cette fenêtre

⚠️ RÉFLÉCHISSEZ BIEN AVANT DE CONTINUER ⚠️"""
    
    def accept_disclaimer(self):
        """Accepte la décharge de responsabilité"""
        self.disclaimer_accepted = True
        return """✅ DÉCHARGE DE RESPONSABILITÉ ACCEPTÉE

🔓 Extension KillRAM activée avec les conditions suivantes :
• Vous assumez tous les risques
• Vous avez sauvegardé vos données importantes
• Vous utilisez cet outil de manière responsable

🎯 COMMANDES DISPONIBLES :

1. ext KillRAM start [intensity] - Démarrer l'attaque mémoire
   • intensity: 1-10 (1=léger, 10=maximum)
   • Exemple: ext KillRAM start 5

2. ext KillRAM stop - Arrêter l'attaque (si possible)

3. ext KillRAM status - Statut de l'attaque

4. ext KillRAM help - Aide complète

⚠️ DERNIÈRE CHANCE DE RECULER ⚠️
Sauvegardez MAINTENANT tout travail important !

💡 Conseil : Commencez par une intensité faible (1-3) pour tester."""
    
    def start_kill_process(self, intensity_str):
        """Démarre le processus de saturation mémoire"""
        if not self.disclaimer_accepted:
            return "❌ Vous devez d'abord accepter la décharge de responsabilité\nUtilisez: ext KillRAM disclaimer"
        
        if self.is_running:
            return "⚠️ KillRAM est déjà en cours d'exécution\nUtilisez 'ext KillRAM stop' pour l'arrêter"
        
        # Déterminer l'intensité
        try:
            intensity = int(intensity_str) if intensity_str else 5
            intensity = max(1, min(10, intensity))  # Limiter entre 1 et 10
        except:
            intensity = 5
        
        # Dernière confirmation
        if intensity >= 8:
            return f"""🚨 INTENSITÉ CRITIQUE DÉTECTÉE : {intensity}/10

⚠️ CETTE INTENSITÉ VA PROBABLEMENT :
• Planter le système immédiatement
• Causer une perte de données
• Nécessiter un redémarrage forcé

🛑 ÊTES-VOUS ABSOLUMENT SÛR ?

Pour confirmer cette intensité dangereuse :
ext KillRAM start {intensity} CONFIRM

Pour choisir une intensité plus sûre (1-7) :
ext KillRAM start [1-7]"""
        
        # Vérifier la confirmation pour les intensités élevées
        if intensity >= 8 and (not intensity_str or "CONFIRM" not in str(intensity_str)):
            return "❌ Confirmation requise pour les intensités 8-10"
        
        # Démarrer l'attaque
        self.is_running = True
        self.start_memory_attack(intensity)
        
        return f"""🚀 KILLRAM DÉMARRÉ - INTENSITÉ {intensity}/10

⏱️ Processus lancé : {len(self.kill_threads)} threads actifs
🎯 Cible : Saturation mémoire système
⚠️ Impact attendu : {'Léger' if intensity <= 3 else 'Modéré' if intensity <= 6 else 'CRITIQUE'}

📊 Utilisez 'ext KillRAM status' pour surveiller
🛑 Utilisez 'ext KillRAM stop' pour arrêter (si le système répond encore)

⚠️ SAUVEGARDEZ VOS DONNÉES MAINTENANT SI CE N'EST PAS FAIT !"""
    
    def start_memory_attack(self, intensity):
        """Lance l'attaque mémoire avec l'intensité spécifiée"""
        # Calculer les paramètres selon l'intensité
        num_threads = intensity * 2
        chunk_size = intensity * 10 * 1024 * 1024  # MB par thread
        
        for i in range(num_threads):
            thread = threading.Thread(target=self.memory_killer_thread, args=(chunk_size, i))
            thread.daemon = True
            thread.start()
            self.kill_threads.append(thread)
            time.sleep(0.1)  # Petit délai entre les threads
    
    def memory_killer_thread(self, chunk_size, thread_id):
        """Thread qui consomme la mémoire"""
        memory_blocks = []
        block_count = 0
        
        try:
            while self.is_running:
                # Allouer de gros blocs de mémoire
                try:
                    # Créer un bloc de données aléatoires
                    block = bytearray(chunk_size)
                    # Remplir avec des données pour éviter l'optimisation
                    for i in range(0, len(block), 1024):
                        block[i:i+4] = (block_count).to_bytes(4, 'big')
                    
                    memory_blocks.append(block)
                    block_count += 1
                    
                    # Petit délai pour ne pas saturer le CPU
                    time.sleep(0.01)
                    
                except MemoryError:
                    # Continuer à essayer même en cas d'erreur mémoire
                    time.sleep(0.1)
                except:
                    break
                    
        except:
            pass
        finally:
            # Nettoyer (si possible)
            try:
                del memory_blocks
                gc.collect()
            except:
                pass
    
    def stop_kill_process(self):
        """Arrête le processus de saturation"""
        if not self.is_running:
            return "ℹ️ KillRAM n'est pas en cours d'exécution"
        
        self.is_running = False
        
        # Attendre un peu que les threads se terminent
        time.sleep(1)
        
        # Forcer le garbage collection
        try:
            gc.collect()
        except:
            pass
        
        self.kill_threads.clear()
        
        return """🛑 KILLRAM ARRÊTÉ

✅ Signal d'arrêt envoyé aux threads
🧹 Nettoyage mémoire tenté
📊 Threads actifs : 0

⚠️ Note : Selon l'intensité utilisée, le système peut :
• Mettre du temps à récupérer
• Nécessiter un redémarrage
• Avoir des performances dégradées temporairement

💡 Surveillez l'utilisation mémoire avec le gestionnaire de tâches"""
    
    def get_status(self):
        """Retourne le statut de l'attaque"""
        if not self.disclaimer_accepted:
            return "❌ Extension non activée - Acceptez d'abord la décharge de responsabilité"
        
        active_threads = len([t for t in self.kill_threads if t.is_alive()])
        
        status = f"""📊 STATUT KILLRAM

🔄 État : {'🔴 ACTIF' if self.is_running else '🟢 ARRÊTÉ'}
🧵 Threads actifs : {active_threads}
💾 Disclaimer accepté : ✅

"""
        
        if self.is_running:
            status += """⚠️ ATTAQUE EN COURS
• Le système peut devenir instable
• Sauvegardez immédiatement vos données
• Préparez-vous à un redémarrage forcé

🛑 Pour arrêter : ext KillRAM stop"""
        else:
            status += """✅ SYSTÈME SÉCURISÉ
• Aucune attaque en cours
• Mémoire en cours de récupération

🚀 Pour démarrer : ext KillRAM start [1-10]"""
        
        return status
    
    def show_help(self):
        """Affiche l'aide"""
        if not self.disclaimer_accepted:
            return self.show_disclaimer()
        
        return """💀 KILLRAM - AIDE

⚠️ OUTIL DE SATURATION MÉMOIRE SYSTÈME ⚠️

🎯 OBJECTIF :
Saturer la mémoire RAM pour tester la robustesse du système
ou simuler des conditions de faible mémoire.

📋 COMMANDES :
• ext KillRAM disclaimer - Voir la décharge de responsabilité
• ext KillRAM accept - Accepter et activer l'extension
• ext KillRAM start [1-10] - Démarrer avec intensité
• ext KillRAM stop - Arrêter l'attaque
• ext KillRAM status - Voir le statut
• ext KillRAM help - Cette aide

🎚️ NIVEAUX D'INTENSITÉ :
1-3 : Léger (test, récupération facile)
4-6 : Modéré (impact notable, récupération possible)
7-8 : Élevé (système instable, redémarrage probable)
9-10 : CRITIQUE (crash quasi-certain)

⚠️ UTILISATIONS LÉGITIMES :
• Tests de stress mémoire
• Simulation de conditions dégradées
• Tests de robustesse d'applications
• Recherche en sécurité

🚫 RAPPEL LÉGAL :
Cet outil est fourni sans garantie. L'utilisateur assume
tous les risques. Le développeur décline toute responsabilité."""
    
    def get_commands(self):
        return ["disclaimer", "accept", "start", "stop", "status", "help"]