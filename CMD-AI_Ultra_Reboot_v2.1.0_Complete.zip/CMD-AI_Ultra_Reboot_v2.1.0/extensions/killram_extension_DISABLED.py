# KILLRAM EXTENSION - DÉSACTIVÉE POUR SÉCURITÉ
# Cette extension est isolée et ne sera PAS chargée par l'application

# CONTENU ORIGINAL DÉPLACÉ VERS UN FICHIER SÉCURISÉ
# Pour réactiver : renommer en killram_extension.py

from core.base_extension import BaseExtension

class KillRAMExtension(BaseExtension):
    def __init__(self):
        super().__init__()
        self.name = "KillRAM"
        self.version = "1.0.0"
        self.description = "🔒 EXTENSION DÉSACTIVÉE POUR SÉCURITÉ"
        self.author = "CMD-AI Team"
    
    def execute(self, command, args=None):
        return """🔒 EXTENSION KILLRAM DÉSACTIVÉE

⚠️ Cette extension a été désactivée pour votre sécurité.

🛡️ RAISONS :
• Risque de crash système
• Perte de données possible
• Outil potentiellement destructif

📁 LOCALISATION :
L'extension complète se trouve dans :
extensions/killram_extension_DISABLED.py

🔓 POUR RÉACTIVER (À VOS RISQUES) :
1. Renommer le fichier en killram_extension.py
2. Redémarrer l'application
3. Accepter la décharge de responsabilité

⚠️ UTILISATION DÉCONSEILLÉE SUR MACHINE DE PRODUCTION"""
    
    def get_commands(self):
        return ["disabled"]