---
name: 💬 Feedback Testeur
about: Retour d'expérience utilisateur
title: '[FEEDBACK] '
labels: ['feedback', 'tester']
assignees: ['votre-username']
---

## 😊 Expérience générale
**Note sur 10:** /10
**Facilité d'utilisation:** Très facile / Facile / Difficile / Très difficile

## ✅ Ce qui fonctionne bien
- 
- 
- 

## ❌ Ce qui pose problème
- 
- 
- 

## 💡 Suggestions d'amélioration
- 
- 
- 

## 🎯 Fonctionnalités testées
- [ ] Installation
- [ ] Configuration IA
- [ ] Chat avec IA
- [ ] Commandes système
- [ ] Extensions
- [ ] Paramètres

## 👤 Profil testeur
**Pseudo:** 
**Expérience informatique:** Débutant/Intermédiaire/Avancé
**Système d'exploitation:** Windows/macOS/Linux
**Temps de test:** minutes/heures

---
*Merci pour votre contribution au projet CMD-AI Ultra Reboot !*