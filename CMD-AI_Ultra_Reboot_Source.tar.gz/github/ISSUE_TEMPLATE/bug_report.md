---
name: 🐛 Rapport de Bug (Testeur)
about: Rapport automatique généré par l'application
title: '[BUG] '
labels: ['bug', 'tester-feedback']
assignees: ['votre-username']
---

## 🐛 Description du problème
<!-- Généré automatiquement par l'application -->

## 💻 Informations système
**OS:** 
**Version Python:** 
**Version CMD-AI:** 
**Architecture:** 

## 🔄 Étapes pour reproduire
1. 
2. 
3. 

## ❌ Erreur rencontrée
```
[Stack trace automatique]
```

## 📊 Logs
```
[Logs automatiques]
```

## 👤 Testeur
**Pseudo:** 
**Niveau technique:** Débutant/Intermédiaire/Avancé
**Première utilisation:** Oui/Non

---
*Rapport généré automatiquement le [DATE] par CMD-AI Ultra Reboot*