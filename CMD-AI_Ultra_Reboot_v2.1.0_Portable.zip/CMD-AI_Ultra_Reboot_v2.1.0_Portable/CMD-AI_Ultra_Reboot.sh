#!/bin/bash
python3 CMD-AI_Ultra_Reboot.py
